# PagarBook - Setup Guide

## Step 1: Go to project folder
cd pagarbook

## Step 2: Run database migrations
python manage.py makemigrations employees salary attendance
python manage.py migrate

## Step 3: Load all pre-stored data
python manage.py loaddata initial_employees
python manage.py loaddata initial_salary
python manage.py loaddata initial_attendance

## Step 4: Create admin user
python manage.py createsuperuser

## Step 5: Start the server
python manage.py runserver

## Step 6: Open in browser
http://127.0.0.1:8000/
