from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Salary
from .forms import SalaryForm


@login_required
def salary_list(request):
    salaries = Salary.objects.select_related('employee').all()
    return render(request, 'salary/list.html', {'salaries': salaries})


@login_required
def salary_add(request):
    if request.method == 'POST':
        form = SalaryForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('salary_list')
    else:
        form = SalaryForm()
    return render(request, 'salary/add.html', {'form': form})


@login_required
def salary_edit(request, pk):
    salary = get_object_or_404(Salary, pk=pk)
    if request.method == 'POST':
        form = SalaryForm(request.POST, instance=salary)
        if form.is_valid():
            form.save()
            return redirect('salary_list')
    else:
        form = SalaryForm(instance=salary)
    return render(request, 'salary/add.html', {'form': form})


@login_required
def salary_delete(request, pk):
    salary = get_object_or_404(Salary, pk=pk)
    salary.delete()
    return redirect('salary_list')


@login_required
def payslip(request, pk):
    salary = get_object_or_404(Salary, pk=pk)
    return render(request, 'salary/payslip.html', {'salary': salary})
