from django.urls import path
from . import views

urlpatterns = [
    path('', views.salary_list, name='salary_list'),
    path('add/', views.salary_add, name='salary_add'),
    path('edit/<int:pk>/', views.salary_edit, name='salary_edit'),
    path('delete/<int:pk>/', views.salary_delete, name='salary_delete'),
    path('payslip/<int:pk>/', views.payslip, name='payslip'),
]
