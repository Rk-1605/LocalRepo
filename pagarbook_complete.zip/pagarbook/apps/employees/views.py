from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Employee
from .forms import EmployeeForm
from apps.salary.models import Salary
from apps.attendance.models import Attendance


@login_required
def dashboard(request):
    total_employees = Employee.objects.filter(is_active=True).count()
    total_salary = sum([s.net_salary for s in Salary.objects.all()])
    recent_employees = Employee.objects.filter(is_active=True)[:5]
    context = {
        'total_employees': total_employees,
        'total_salary': total_salary,
        'recent_employees': recent_employees,
    }
    return render(request, 'dashboard.html', context)


@login_required
def employee_list(request):
    query = request.GET.get('q', '')
    employees = Employee.objects.filter(is_active=True)
    if query:
        employees = employees.filter(name__icontains=query)
    return render(request, 'employees/list.html', {'employees': employees, 'query': query})


@login_required
def employee_add(request):
    if request.method == 'POST':
        form = EmployeeForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('employee_list')
    else:
        form = EmployeeForm()
    return render(request, 'employees/add.html', {'form': form, 'title': 'Add Employee'})


@login_required
def employee_edit(request, pk):
    employee = get_object_or_404(Employee, pk=pk)
    if request.method == 'POST':
        form = EmployeeForm(request.POST, instance=employee)
        if form.is_valid():
            form.save()
            return redirect('employee_list')
    else:
        form = EmployeeForm(instance=employee)
    return render(request, 'employees/add.html', {'form': form, 'title': 'Edit Employee'})


@login_required
def employee_delete(request, pk):
    employee = get_object_or_404(Employee, pk=pk)
    employee.is_active = False
    employee.save()
    return redirect('employee_list')


@login_required
def employee_detail(request, pk):
    employee = get_object_or_404(Employee, pk=pk)
    salaries = Salary.objects.filter(employee=employee).order_by('-year', '-month')
    attendances = Attendance.objects.filter(employee=employee).order_by('-date')[:10]
    return render(request, 'employees/detail.html', {
        'employee': employee,
        'salaries': salaries,
        'attendances': attendances,
    })
