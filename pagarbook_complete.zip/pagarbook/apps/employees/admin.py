from django.contrib import admin
from .models import Employee

@admin.register(Employee)
class EmployeeAdmin(admin.ModelAdmin):
    list_display = ['name', 'department', 'position', 'basic_salary', 'is_active']
    search_fields = ['name', 'email']
