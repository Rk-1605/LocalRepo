from django.urls import path
from . import views

urlpatterns = [
    path('', views.attendance_mark, name='attendance_mark'),
    path('delete/<int:pk>/', views.attendance_delete, name='attendance_delete'),
]
