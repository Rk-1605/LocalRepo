from django.db import models
from apps.employees.models import Employee

STATUS_CHOICES = [
    ('present', 'Present'),
    ('absent', 'Absent'),
    ('half_day', 'Half Day'),
    ('leave', 'Leave'),
]

class Attendance(models.Model):
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    date = models.DateField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='present')
    notes = models.TextField(blank=True)

    def __str__(self):
        return f"{self.employee.name} - {self.date} - {self.status}"

    class Meta:
        unique_together = ['employee', 'date']
        ordering = ['-date']
