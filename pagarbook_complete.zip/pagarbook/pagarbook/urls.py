from django.contrib import admin
from django.urls import path, include
from django.contrib.auth import views as auth_views
from apps.employees import views as emp_views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', emp_views.dashboard, name='dashboard'),
    path('login/', auth_views.LoginView.as_view(template_name='login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('employees/', include('apps.employees.urls')),
    path('salary/', include('apps.salary.urls')),
    path('attendance/', include('apps.attendance.urls')),
]
